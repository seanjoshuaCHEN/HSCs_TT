import warnings
warnings.filterwarnings('ignore')
warnings.simplefilter('ignore')
import torch, yaml, cv2, os, shutil
import numpy as np
import matplotlib.pyplot as plt
from tqdm import trange
from PIL import Image
from ultralytics.nn.tasks import DetectionModel as Model
from ultralytics.utils.torch_utils import intersect_dicts
from ultralytics.utils.ops import xywh2xyxy
from pytorch_grad_cam import GradCAMPlusPlus, GradCAM, XGradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.activations_and_gradients import ActivationsAndGradients

def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True, stride=32):
    shape = im.shape[:2]  # 当前尺寸 [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # 计算缩放比例时初始化ratio
    r = min(new_shape[0]/shape[0], new_shape[1]/shape[1])
    ratio = (r, r)  # 添加默认初始化 <--- 关键修复
    
    if not scaleup:
        r = min(r, 1.0)

    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]

    if auto:
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)
    elif scaleFill:
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = (new_shape[1]/shape[1], new_shape[0]/shape[0])  # 覆盖默认值

    dw /= 2
    dh /= 2

    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    return cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color), ratio, (dw, dh)

class yolov11_heatmap:
    def __init__(self, weight, cfg, device, method, layer, backward_type, conf_threshold, ratio):
        # 初始化部分保持不变
        device = torch.device(device)
        ckpt = torch.load(weight)
        model_names = ckpt['model'].names
        csd = ckpt['model'].float().state_dict()
        model = Model(cfg, ch=3, nc=len(model_names)).to(device)
        csd = intersect_dicts(csd, model.state_dict(), exclude=['anchor'])
        model.load_state_dict(csd, strict=False)
        model.eval()

        target_layers = [eval(layer)]
        method = eval(method)
        colors = np.random.uniform(0, 255, size=(len(model_names), 3)).astype(np.int32)
        self.__dict__.update(locals())

    def post_process(self, result):
        # 后处理保持不变
        logits_ = result[:, 4:]
        boxes_ = result[:, :4]
        sorted, indices = torch.sort(logits_.max(1)[0], descending=True)
        return torch.transpose(logits_[0], dim0=0, dim1=1)[indices[0]], torch.transpose(boxes_[0], dim0=0, dim1=1)[indices[0]], xywh2xyxy(torch.transpose(boxes_[0], dim0=0, dim1=1)[indices[0]]).cpu().detach().numpy()

    def __call__(self, img_path, save_path):
        # 创建保存目录
        os.makedirs(save_path, exist_ok=True)
        
        # 图像预处理
        orig_img = cv2.imread(img_path)
        img = letterbox(orig_img)[0]
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_normalized = np.float32(img_rgb) / 255.0
        tensor = torch.from_numpy(np.transpose(img_normalized, [2, 0, 1])).unsqueeze(0).to(self.device)

        # 初始化梯度计算
        grads = ActivationsAndGradients(self.model, self.target_layers, reshape_transform=None)
        result = grads(tensor)
        activations = grads.activations[0].cpu().detach().numpy()

        # 后处理
        post_result, pre_post_boxes, post_boxes = self.post_process(result[0])
        
        # 初始化热力图叠加层
        combined_cam = np.zeros_like(img_normalized[:, :, 0])
        detection_image = orig_img.copy()  # 用于绘制检测框的原始图像

        # 进度条循环
        valid_detections = 0
        for i in trange(int(post_result.size(0) * self.ratio)):
            if float(post_result[i].max()) < self.conf_threshold or valid_detections >= 10:  # 最多处理10个检测
                break
            
            self.model.zero_grad()
            # 梯度计算逻辑保持不变
            if self.backward_type in ['class', 'all']:
                score = post_result[i].max()
                score.backward(retain_graph=True)
            
            if self.backward_type in ['box', 'all']:
                for j in range(4):
                    score = pre_post_boxes[i, j]
                    score.backward(retain_graph=True)
            
            # 热力图生成
            gradients = grads.gradients[0] if self.backward_type == 'class' else \
                       sum(grads.gradients[:4]) if self.backward_type == 'box' else \
                       sum(grads.gradients)
            
            weights = self.method.get_cam_weights(self.method, None, None, None, activations, gradients.detach().numpy())
            weights = weights.reshape((1, -1, 1, 1))
            saliency_map = np.sum(weights * activations, axis=1)
            saliency_map = np.squeeze(np.maximum(saliency_map, 0))
            
            # 调整尺寸并归一化
            saliency_map = cv2.resize(saliency_map, (tensor.size(3), tensor.size(2)))
            saliency_map = (saliency_map - saliency_map.min()) / (saliency_map.max() - saliency_map.min() + 1e-8)
            
            # 叠加热力图
            combined_cam = np.maximum(combined_cam, saliency_map)  # 取各检测的最大响应
            
            # 绘制检测框
            x1, y1, x2, y2 = map(int, post_boxes[i])
            color = [int(c) for c in self.colors[int(post_result[i, :].argmax())]]
            cv2.rectangle(detection_image, (x1, y1), (x2, y2), color, 2)
            label = f"{self.model_names[int(post_result[i, :].argmax())]} {float(post_result[i].max()):.2f}"
            cv2.putText(detection_image, label, (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            
            valid_detections += 1

        # 生成最终热力图
        if valid_detections > 0:
            # 调整热力图尺寸到原始图像
            combined_cam = cv2.resize(combined_cam, (orig_img.shape[1], orig_img.shape[0]))
            combined_cam = (combined_cam - combined_cam.min()) / (combined_cam.max() - combined_cam.min() + 1e-8)
            
            # 叠加热力图到原图
            heatmap_image = show_cam_on_image(cv2.cvtColor(orig_img, cv2.COLOR_BGR2RGB)/255.0, 
                                            combined_cam, 
                                            use_rgb=True,
                                            image_weight=0.5)  # 调整透明度
            
            # 融合检测框
            #final_image = cv2.addWeighted(heatmap_image, 0.7, 
                                        #cv2.cvtColor(detection_image, cv2.COLOR_BGR2RGB), 0.3, 0)
            
            # 保存单张结果图
            output_path = os.path.join(save_path, 'combined_result.jpg')
            Image.fromarray(final_image).save(output_path)
        else:
            print("未检测到有效目标")

# 保持get_params和main部分完全不变
def get_params():
    params = {
        'weight': r'C:\Users\admin\Desktop\yolov11\best.pt',
        'cfg': r'C:\Users\admin\Desktop\yolov11\nn-sLsH-2-sHLFAE.yaml',
        'method': 'GradCAM',
        'device': 'cuda:0',
        'layer': 'model.model[9]',
        'backward_type': 'box',
        'conf_threshold': 0.6,
        'ratio': 0.02
    }
    return params

if __name__ == '__main__':
    model = yolov11_heatmap(**get_params())
    model(r'C:\Users\admin\Desktop\yolov11\ultralytics\assets\84a.jpg', 'result/v11')