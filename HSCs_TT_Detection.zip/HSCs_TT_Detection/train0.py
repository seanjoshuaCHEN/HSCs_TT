from ultralytics import YOLO  as YOLO
import warnings

warnings.filterwarnings('ignore')

# 模型配置文件
model_yaml_path = "ultralytics\cfg\models\HSCs\YOLOv11n-OBB-LP-HP-HLFM.yaml"
#数据集配置文件
data_yaml_path = "HSCs_0_a.yaml"

if __name__ == '__main__':
    
    model = YOLO(model_yaml_path)
    #训练模型
    results = model.train(data=data_yaml_path,
                          epochs=400,
                          batch=64,
                          workers=12,
                          iou_type="Ciou",
                          imgsz=1024)
