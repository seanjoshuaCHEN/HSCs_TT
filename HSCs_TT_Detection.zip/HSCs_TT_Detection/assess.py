from ultralytics import YOLO

if __name__ == '__main__':
    # 加载模型
    model = YOLO(r"C:\Users\admin\Desktop\YOLO_Demo3\runs\obb\train232\weights\best.pt")

    # 评估模型
    metrics = model.val(data=r"C:\Users\admin\Desktop\YOLO_Demo3\HSCs_1_b.yaml")

    # 打印评估结果
    print(metrics)


