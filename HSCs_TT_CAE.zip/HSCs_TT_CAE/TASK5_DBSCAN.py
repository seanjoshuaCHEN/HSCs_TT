import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import DBSCAN
from sklearn.decomposition import PCA
import os

# 1⃣ 指定存放图片的文件夹
image_folder = "HSCs_Padded3"

# 获取所有图片的文件名，并按字母顺序排序
filenames = sorted([f for f in os.listdir(image_folder) if f.endswith(('.jpg', '.png', '.jpeg'))])
print(f"加载的文件数：{len(filenames)}")  # 确保和 features.npy 样本数一致

# 2⃣ 加载特征数据
features = np.load("recovered_features.npy")
print(f"特征数据加载完成，形状：{features.shape}")  # (num_images, 64)

# 3⃣ 计算 k 近邻距离曲线，寻找最佳 eps
def find_optimal_eps(features, k=72):
    nbrs = NearestNeighbors(n_neighbors=k).fit(features)
    distances, indices = nbrs.kneighbors(features)
    k_distances = np.sort(distances[:, -1])
    
    plt.figure(figsize=(8, 5))
    plt.plot(k_distances)
    plt.xlabel("Points sorted by distance")
    plt.ylabel(f"{k}-th Nearest Neighbor Distance")
    plt.title("k-distance Graph for DBSCAN eps selection")
    plt.show()

find_optimal_eps(features, k=5)

# 4⃣ 设置 DBSCAN 参数
optimal_eps = 8
min_samples = 5

dbscan = DBSCAN(eps=optimal_eps, min_samples=min_samples)
labels = dbscan.fit_predict(features)

# 5⃣ 可视化聚类结果（使用 PCA 降维到 2D）
pca = PCA(n_components=2)
features_2d = pca.fit_transform(features)

plt.figure(figsize=(10, 5))
plt.scatter(features_2d[:, 0], features_2d[:, 1], c=labels, cmap='viridis', s=10)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("DBSCAN Clustering Result")
plt.show()

# 6⃣ 输出聚类统计信息
num_clusters = len(set(labels)) - (1 if -1 in labels else 0)
num_noise = list(labels).count(-1)
print(f"检测到的聚类数: {num_clusters}")
print(f"噪声点数量: {num_noise}")

# 7⃣ 保存聚类结果到 CSV，包含样本名称
output_file = "dbscan_clusters_with_filenames_task5.csv"
df = pd.DataFrame({"Filename": filenames, "Cluster_Label": labels})
df.to_csv(output_file, index=False)
print(f"聚类信息已保存至 {output_file}")
