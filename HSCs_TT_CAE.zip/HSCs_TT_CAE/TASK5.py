import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import cv2
import matplotlib.pyplot as plt

# 图片数据路径
image_folder = "HSCs_Padded3"

# 设定超参数
IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS = 407, 407, 3  # 更新图片尺寸
LATENT_DIM = 64  # 降维后的特征维度
BATCH_SIZE = 32
EPOCHS = 100

# 1️⃣ 读取数据集并预处理
def load_images(image_folder):
    images = []
    filenames = []
    
    for filename in os.listdir(image_folder):
        if filename.endswith('.jpg'):
            img_path = os.path.join(image_folder, filename)
            img = cv2.imread(img_path)  # BGR格式
            
            if img is not None:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # 转为 RGB
                img = img.astype('float32') / 255.0  # 归一化
                images.append(img)
                filenames.append(filename)
    
    images = np.array(images)
    return images, filenames

images, filenames = load_images(image_folder)
print(f"数据集加载完成，共 {len(images)} 张图片，形状：{images.shape}")  # (num_images, 407, 407, 3)

# 2️⃣ **修正的卷积自编码器**
def build_autoencoder():
    input_img = keras.Input(shape=(IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS))

    # **Encoder**
    x = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(input_img)
    x = layers.MaxPooling2D((2, 2), padding='same')(x)  # 204x204
    x = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(x)
    x = layers.MaxPooling2D((2, 2), padding='same')(x)  # 102x102
    x = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(x)
    x = layers.MaxPooling2D((2, 2), padding='same')(x)  # 51x51
    
    # Flatten 并连接到潜在空间
    x = layers.Flatten()(x)
    latent = layers.Dense(LATENT_DIM, activation='relu', name='latent_vector')(x)

    # **Decoder（确保最终输出为 407x407）**
    x = layers.Dense((51 * 51 * 128), activation='relu')(latent)  
    x = layers.Reshape((51, 51, 128))(x)
    x = layers.Conv2DTranspose(128, (3, 3), activation='relu', padding='same')(x)
    x = layers.UpSampling2D((2, 2))(x)  # 102x102
    x = layers.Conv2DTranspose(64, (3, 3), activation='relu', padding='same')(x)
    x = layers.UpSampling2D((2, 2))(x)  # 204x204
    x = layers.Conv2DTranspose(32, (3, 3), activation='relu', padding='same')(x)
    x = layers.UpSampling2D((2, 2))(x)  # 408x408

    # **裁剪层，确保 408x408 → 407x407**
    x = layers.Cropping2D(cropping=((1, 0), (1, 0)))(x)

    output_img = layers.Conv2D(IMG_CHANNELS, (3, 3), activation='sigmoid', padding='same')(x)  

    # 定义模型
    autoencoder = keras.Model(input_img, output_img)
    encoder = keras.Model(input_img, latent)  # 只取编码部分

    return autoencoder, encoder

autoencoder, encoder = build_autoencoder()
autoencoder.compile(optimizer='adam', loss='mse')

# 3️⃣ 训练自编码器
history = autoencoder.fit(images, images,
                          epochs=EPOCHS,
                          batch_size=BATCH_SIZE,
                          validation_split=0.1)

# 4️⃣ 保存模型
autoencoder.save("CAE_model_task5.h5")
encoder.save("Encoder_model__task5.h5")
print("模型已保存")

# 5️⃣ 提取降维特征
features = encoder.predict(images)
np.save("features_task5.npy", features)
print("特征已保存，形状：", features.shape)  # (num_images, 64)

# 6️⃣ 绘制训练损失曲线
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.title('Training Loss Curve')
plt.show()
